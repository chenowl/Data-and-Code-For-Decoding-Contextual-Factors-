import pandas as pd
import matplotlib.pyplot as plt
import shap
from sklearn.svm import LinearSVC

data = pd.read_excel('data.xlsx', header=0)
y = data['PV1READ_label']
X = data.drop(labels=['PV1READ_label'], axis=1)

model = LinearSVC()
model.fit(X, y)

# clustering for simplifying the computaional process
X_train = X.iloc[0:100]
X_train_summary = shap.kmeans(X, 10)
explainerKNN = shap.KernelExplainer(model.predict, data=X_train_summary)
shap_values = explainerKNN.shap_values(X_train)

# bar chart
plt.title('SHAPValues of SVM')
shap.summary_plot(shap_values, X_train,  plot_type="bar", max_display=20)
plt.savefig('bar.png')
# scattered plot chart
plt.title('SHAP value of SVM', fontsize=25)
shap.summary_plot(shap_values, X_train, max_display=40, show=False)
plt.savefig('sc.png')


# conserving shap_values
shap_values = pd.DataFrame(shap_values)
shap_values.to_excel('./shapvalues_temporary.xlsx')
